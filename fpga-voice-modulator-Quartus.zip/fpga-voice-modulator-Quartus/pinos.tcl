# Clock de 50 MHz e Botao de Reset
set_location_assignment PIN_Y2   -to CLOCK_50
set_location_assignment PIN_M23  -to KEY0

# Pinos fisicos corretos do SD Card (DE2-115)
set_location_assignment PIN_AE13 -to SD_CLK
set_location_assignment PIN_AD14 -to SD_CMD
set_location_assignment PIN_AE14 -to SD_DAT0

# LEDs de diagnostico (LEDR 0 a 3)
set_location_assignment PIN_G19  -to LEDR[0]
set_location_assignment PIN_F19  -to LEDR[1]
set_location_assignment PIN_E19  -to LEDR[2]
set_location_assignment PIN_F21  -to LEDR[3]

# Display HEX0 (Nibble baixo do contador)
set_location_assignment PIN_G18  -to HEX0[0]
set_location_assignment PIN_F22  -to HEX0[1]
set_location_assignment PIN_E17  -to HEX0[2]
set_location_assignment PIN_L26  -to HEX0[3]
set_location_assignment PIN_L25  -to HEX0[4]
set_location_assignment PIN_J22  -to HEX0[5]
set_location_assignment PIN_H22  -to HEX0[6]

# Display HEX1 (Nibble alto do contador)
set_location_assignment PIN_M24  -to HEX1[0]
set_location_assignment PIN_Y22  -to HEX1[1]
set_location_assignment PIN_W21  -to HEX1[2]
set_location_assignment PIN_W22  -to HEX1[3]
set_location_assignment PIN_W25  -to HEX1[4]
set_location_assignment PIN_U23  -to HEX1[5]
set_location_assignment PIN_U24  -to HEX1[6]

# Padroes eletricos I/O da placa
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to CLOCK_50
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to KEY0
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to SD_*
set_instance_assignment -name IO_STANDARD "2.5 V"       -to LEDR[*]
set_instance_assignment -name IO_STANDARD "2.5 V"       -to HEX*