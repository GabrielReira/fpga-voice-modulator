transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog  -work work +incdir+D:/LABIII {D:/LABIII/wav_reader.v}
vlog  -work work +incdir+D:/LABIII {D:/LABIII/top_wav_sd.v}
vlog  -work work +incdir+D:/LABIII {D:/LABIII/sd_file_reader.v}
vlog  -work work +incdir+D:/LABIII {D:/LABIII/sd_reader.v}
vlog  -work work +incdir+D:/LABIII {D:/LABIII/sdcmd_ctrl.v}

vlog  -work work +incdir+D:/LABIII {D:/LABIII/tb_top_wav_sd.v}
vlog  -work work +incdir+D:/LABIII {D:/LABIII/sd_card_mock.v}

vsim -t 1ps -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cycloneive_ver -L rtl_work -L work -voptargs="+acc"  tb_top_wav_sd

add wave *
view structure
view signals
run -all
